window._config = {
    cognito: {
        userPoolId:    'us-west-2_jpWPdSKuH',         // e.g. us-east-2_uXboG5pAb
        userPoolClientId:   '4poc7n584hkgu2v4ql5bomkauk',         // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region:             'us-west-2'          // e.g. us-east-2
    },
    api: {
        invokeUrl:          ''          // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
