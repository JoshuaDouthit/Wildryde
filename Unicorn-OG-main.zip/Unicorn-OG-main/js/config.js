window._config = {
    cognito: {
        userPoolId:         '',         // e.g. us-east-2_uXboG5pAb
        userPoolClientId:   '',         // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region:             ''          // e.g. us-east-2
    },
    api: {
        invokeUrl:          ''          // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
