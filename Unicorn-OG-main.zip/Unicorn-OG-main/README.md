# wildrydes-site
[Repo for the Project](https://github.com/gtjames/Unicorn-OG)
[Conifg file where all the magic is stored](./js/config.js)